echo "Removing Old Data"
rm data/synthethic_json/*
rm data/synthethic_dtapn/*
rm data/synthethic_ltl/*
rm data/synthethic_tapaal/*

rm data/zoo_json/*
rm data/zoo_dtapn/*
rm data/zoo_ltl/*
rm data/zoo_tapaal/*

rm data/time/Disjoint/*
rm data/time/Shared/*
rm data/time/Worst/*
rm data/time/Zoo/*

rm data/synthethic_results/*
rm data/zoo_results/*

echo "Removal done!"
